package com.infy.api;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.infy.model.Product;
import com.infy.service.SellerService;
import com.infy.service.SellerServiceImpl;
import com.infy.utility.ContextFactory;

@CrossOrigin
@RestController
@RequestMapping("SellerAPI")
public class SellerAPI {

	private SellerService service;
	
	@RequestMapping(value="show/{username}", method = RequestMethod.GET)
	public ResponseEntity<List<Product>> showMySoldProducts(@PathVariable String username) throws Exception{
		
		service = ContextFactory.getContext().getBean(SellerServiceImpl.class);
		List<Product> myProducts = service.showMySoldProducts(username);
		if(myProducts == null || myProducts.size()==0)
			return new ResponseEntity<List<Product>>(myProducts, HttpStatus.BAD_REQUEST);
		else
			return new ResponseEntity<List<Product>>(myProducts, HttpStatus.OK);
	}
	
	@PostMapping(value="addProduct")
	public ResponseEntity<Product> addroduct(@RequestBody Product product) throws Exception{
		
		service = ContextFactory.getContext().getBean(SellerServiceImpl.class);
		
		Integer productId=service.addProduct(product);
		
		if(productId!=null){
			product.setProductId(productId);
			return new ResponseEntity<Product>(product, HttpStatus.OK);
		}
		
		return null;
	}
	
	@RequestMapping(value="getMyProducts/{username}", method = RequestMethod.GET)
	public ResponseEntity<List<Product>> getMyProducts(@PathVariable String username) throws Exception{
		
		service = ContextFactory.getContext().getBean(SellerServiceImpl.class);
		List<Product> products = service.getMyProducts(username);
		if(products == null || products.size()==0)
			return new ResponseEntity<List<Product>>(products, HttpStatus.BAD_REQUEST);
		else
			return new ResponseEntity<List<Product>>(products, HttpStatus.OK);
		
	}
	
	@PostMapping(value="updateProductDetails")
	public ResponseEntity<String> updateProductDetails(@RequestBody Product product)throws Exception{
		
		service = ContextFactory.getContext().getBean(SellerServiceImpl.class);
		String username = service.updateProductDetails(product);
		if(username != null &&!username.isEmpty())
			return new ResponseEntity<String>(username, HttpStatus.OK);
		return new ResponseEntity<String>("Failure", HttpStatus.BAD_REQUEST);
	}

	@RequestMapping(value="deleteProduct", method = RequestMethod.PUT)
	public ResponseEntity<String> deleteProduct(@RequestBody Product product) throws Exception{
		service = ContextFactory.getContext().getBean(SellerServiceImpl.class);
		String sucessMessage =service.deleteProduct(product);
		if(sucessMessage!=null){
			return new ResponseEntity<String>("Sucessfully Deleted",HttpStatus.OK);
		}
		else{
			return new ResponseEntity<String>("Failed to delete",HttpStatus.BAD_REQUEST);
		}
		
	}
	
	@RequestMapping(value="searchByCategory/{category}", method = RequestMethod.GET)
	public ResponseEntity<List<Product>> searchByCategory(@PathVariable String category) throws Exception{
		
		service = ContextFactory.getContext().getBean(SellerServiceImpl.class);
		List<Product> products = service.searchByCategory(category);
		if(products == null || products.size()==0)
			return new ResponseEntity<List<Product>>(products, HttpStatus.BAD_REQUEST);
		else
			return new ResponseEntity<List<Product>>(products, HttpStatus.OK);
		
	}
	
}