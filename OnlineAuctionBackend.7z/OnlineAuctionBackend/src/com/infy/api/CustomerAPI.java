package com.infy.api;

import java.util.List;

import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.infy.model.Customer;
import com.infy.model.Feedback;
import com.infy.model.Password;
import com.infy.service.CustomerService;
import com.infy.service.CustomerServiceImpl;
import com.infy.utility.ContextFactory;
import com.infy.utility.LogConfig;

@CrossOrigin
@RestController
@RequestMapping("CustomerAPI")
public class CustomerAPI {

	private CustomerService service;
	final static Logger LOGGER = LogConfig.getLogger(CustomerAPI.class);
	
	@RequestMapping(value="login", method = RequestMethod.GET)
	public ResponseEntity<String> loginCustomer(@RequestParam("email") String email) throws Exception{
		
		service = ContextFactory.getContext().getBean(CustomerServiceImpl.class);
		try{
			
			String pwd = service.loginCustomer(email);
			return new ResponseEntity<String>(pwd, HttpStatus.OK);
		} catch(Exception e){
			return new ResponseEntity<String>("null", HttpStatus.OK);
		}
	}
	
	@RequestMapping(value="getUsers", method=RequestMethod.GET)
	public ResponseEntity<List<String>> getUsernames() throws Exception{
		
		service = ContextFactory.getContext().getBean(CustomerServiceImpl.class);
		List<String> usernames = service.getUsernames();
		return new ResponseEntity<List<String>>(usernames, HttpStatus.OK);
		
	}
	
	@RequestMapping(value="register", method = RequestMethod.POST)
	public ResponseEntity<Customer> registerCustomer(@RequestBody Customer customer) throws Exception{
		
		service = ContextFactory.getContext().getBean(CustomerServiceImpl.class);
		Customer customer1 = service.registerCustomer(customer);
		return new ResponseEntity<Customer>(customer1, HttpStatus.OK);
		
	}
	
	@RequestMapping(value="addDp/{username}", method=RequestMethod.POST)
	public ResponseEntity<String> addProfilePicture(@PathVariable String username, @RequestBody String pic) throws Exception{
		
		service = ContextFactory.getContext().getBean(CustomerServiceImpl.class);
		String status = service.addProfilePicture(username, pic);
		return new ResponseEntity<String>(status, HttpStatus.OK);
		
	}
	
	@RequestMapping(value="getDp/{username}", method=RequestMethod.GET)
	public ResponseEntity<String> getProfilePicture(@PathVariable String username) throws Exception {
		
		service = ContextFactory.getContext().getBean(CustomerServiceImpl.class);
		String pic = service.getProfilePicture(username);
		if(pic == null)
			return new ResponseEntity<String>("", HttpStatus.OK);
		return new ResponseEntity<String>(pic, HttpStatus.OK);
		
	}
	
	@RequestMapping(value="myDetails", method = RequestMethod.POST)
	public ResponseEntity<Customer> showmyDetails(@RequestBody String email) throws Exception{
		
		service = ContextFactory.getContext().getBean(CustomerServiceImpl.class);
		Customer customer = service.showMyDetails(email);
		return new ResponseEntity<Customer>(customer, HttpStatus.OK);
		
	}
	
	@PostMapping(value="updateProfile")
	public ResponseEntity<String> updateProfile(@RequestBody Customer customer)throws Exception{
		
		service = ContextFactory.getContext().getBean(CustomerServiceImpl.class);
		String username = service.updateProfile(customer);
		if(username != null &&!username.isEmpty())
			return new ResponseEntity<String>(username, HttpStatus.OK);
		return new ResponseEntity<String>("Failure", HttpStatus.BAD_REQUEST);
	}
	
	@PostMapping(value="changePassword/{username}")
	public ResponseEntity<String> changePassword(@PathVariable String username, @RequestBody Password password) throws Exception{
		
		service = ContextFactory.getContext().getBean(CustomerServiceImpl.class);
		String message = service.changePassword(username, password);
		return new ResponseEntity<String>(message, HttpStatus.OK);
		
	}
	
	@PostMapping(value="submitFeedback")
	public ResponseEntity<String> submitFeedback(@RequestBody Feedback fb) throws Exception{
		
		service = ContextFactory.getContext().getBean(CustomerServiceImpl.class);
		String message = service.submitFeedback(fb);
		return new ResponseEntity<String>(message, HttpStatus.OK);
		
	}
}