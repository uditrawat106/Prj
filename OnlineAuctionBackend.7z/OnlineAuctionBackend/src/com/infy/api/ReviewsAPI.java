package com.infy.api;

import java.util.List;

import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.infy.model.Product;
import com.infy.model.ReviewsModel;
import com.infy.service.BidderService;
import com.infy.service.BidderServiceImpl;
import com.infy.service.ReviewService;
import com.infy.service.ReviewServiceImpl;
import com.infy.utility.ContextFactory;


@CrossOrigin
@RestController
@RequestMapping("ReviewsAPI")
public class ReviewsAPI {
	
	private ReviewService service;
	private Environment environment;
	
	
	@RequestMapping(value="addReview/{rev}", method = RequestMethod.POST)
	public ResponseEntity<String> addReview(@PathVariable("rev") String review) throws Exception{
		
		service = ContextFactory.getContext().getBean(ReviewServiceImpl.class);
	    String s=service.addReview(review);
		return new ResponseEntity<String>(s,HttpStatus.OK);
	}

}
