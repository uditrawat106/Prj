package com.infy.api;

import java.util.List;

import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.infy.model.Product;
import com.infy.service.BidderService;
import com.infy.service.BidderServiceImpl;
import com.infy.utility.ContextFactory;
import com.infy.utility.LogConfig;

@CrossOrigin
@RestController
@RequestMapping("BidderAPI")
public class BidderAPI {

	private BidderService service;
	private Environment environment;
	
	@RequestMapping(value="bid/{username}/{productId}",method=RequestMethod.POST)
	public ResponseEntity<String> bidOnProducts(@PathVariable("username") String username,@PathVariable("productId") 
		Integer productId,@RequestParam("bid") Double bid) throws Exception{
		
		service = ContextFactory.getContext().getBean(BidderServiceImpl.class);
		environment = ContextFactory.getContext().getEnvironment();
		try{
			String message=service.bidOnProduct(username, productId, bid);
			return new ResponseEntity<String>(message,HttpStatus.OK);
		}
		catch(Exception e){
			LogConfig.getLogger(BidderAPI.class).error(e.getMessage(), e);
			if(e.getMessage().contains("DAO"))
				return new ResponseEntity<String>(environment.getProperty(e.getMessage()),HttpStatus.OK);
			return new ResponseEntity<String>(e.getMessage(),HttpStatus.BAD_REQUEST);
		}
		
	}
	
	@RequestMapping(value="show/{username}", method = RequestMethod.GET)
	public ResponseEntity<List<Product>> showMyBidProducts(@PathVariable("username") String username) throws Exception{
		
		service = ContextFactory.getContext().getBean(BidderServiceImpl.class);
		List<Product> myProducts = service.showMyBidProducts(username);
		if(myProducts == null || myProducts.size()==0)
			return new ResponseEntity<List<Product>>(myProducts, HttpStatus.BAD_REQUEST);
		else
			return new ResponseEntity<List<Product>>(myProducts, HttpStatus.OK);
	}
	
	
	@RequestMapping(value="showProducts", method=RequestMethod.GET)
	public ResponseEntity<List<Product>> showAboutToExpireProducts() throws Exception{
		
		service = ContextFactory.getContext().getBean(BidderServiceImpl.class);
		List<Product> products = service.showAboutToExpireProducts();
		if(products == null || products.size()==0)
			return new ResponseEntity<List<Product>>(products, HttpStatus.BAD_REQUEST);
		else
			return new ResponseEntity<List<Product>>(products, HttpStatus.OK);
		
	}
	
	@RequestMapping(value="newProducts", method = RequestMethod.GET)
	public ResponseEntity<List<Product>> showNewlyAddedProducts() throws Exception{
		service = ContextFactory.getContext().getBean(BidderServiceImpl.class);
		List<Product> products = service.showNewlyAddedProducts();
		if(products == null || products.size()==0)
			return new ResponseEntity<List<Product>>(products, HttpStatus.BAD_REQUEST);
		else
			return new ResponseEntity<List<Product>>(products, HttpStatus.OK);
	}
	
	@RequestMapping(value="soldProducts", method = RequestMethod.GET)
	public ResponseEntity<List<Product>> showSoldProducts() throws Exception{
		
		service = ContextFactory.getContext().getBean(BidderServiceImpl.class);
		List<Product> products = service.showSoldProducts();
		if(products == null || products.size()==0)
			return new ResponseEntity<List<Product>>(products, HttpStatus.BAD_REQUEST);
		else
			return new ResponseEntity<List<Product>>(products, HttpStatus.OK);
		
	}
	
	@RequestMapping(value="searchProducts", method=RequestMethod.GET)
	public ResponseEntity<List<Product>>  showSearchProducts(@RequestParam("search") String search) throws Exception{
		
		service = ContextFactory.getContext().getBean(BidderServiceImpl.class);
		List<Product> products = service.showSearchedProducts(search);
		if(products == null || products.size()==0)
			return new ResponseEntity<List<Product>>(products, HttpStatus.BAD_REQUEST);
		else
			return new ResponseEntity<List<Product>>(products, HttpStatus.OK);
		
	}
	
	@RequestMapping(value="nearbyProducts", method = RequestMethod.GET)
	public ResponseEntity<List<Product>> showProductsAtLocation(@RequestParam("location") String location) throws Exception{
		
		service = ContextFactory.getContext().getBean(BidderServiceImpl.class);
		List<Product> products = service.showProductAtLocattion(location);
		if(products == null || products.size()==0)
			return new ResponseEntity<List<Product>>(products, HttpStatus.BAD_REQUEST);
		else
			return new ResponseEntity<List<Product>>(products, HttpStatus.OK);
		
	}
}
