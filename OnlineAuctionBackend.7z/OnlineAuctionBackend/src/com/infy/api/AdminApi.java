package com.infy.api;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.infy.model.AdminDetails;
import com.infy.model.Customer;
import com.infy.model.Product;
import com.infy.service.AdminService;
import com.infy.service.AdminServiceImpl;
import com.infy.utility.ContextFactory;

@RestController
@CrossOrigin
@RequestMapping(value="AdminAPI")
public class AdminApi {

	private AdminService service;
	
	@RequestMapping(method=RequestMethod.GET, value="login/{username}")
	public ResponseEntity<String> login(@PathVariable String username){
		System.out.println(username);
		String pwd=new String();
		ResponseEntity<String> responseEntity = null;
		try{
			service=(AdminService) ContextFactory.getContext().getBean(AdminServiceImpl.class);
			System.out.println(service.login(username));
			pwd=service.login(username);
			System.out.println(pwd);
			if(pwd!=null){
			responseEntity=new ResponseEntity<String>(pwd,HttpStatus.OK);
			
			}
			
		}
		catch(Exception e){
			
			return null;
		}
		return responseEntity;
	} 
	
	@RequestMapping(method=RequestMethod.GET,value="getAdminDetails")
	public ResponseEntity<AdminDetails> getAdminDetails(){
		
		ResponseEntity<AdminDetails> responseEntity=null;
		try{
			service=(AdminService) ContextFactory.getContext().getBean(AdminServiceImpl.class);
			AdminDetails ad= service.getAdminDetails();
			responseEntity =new ResponseEntity<>(ad,HttpStatus.OK);
		}catch(Exception e){
			return null;
		}
		return responseEntity;
	}
	
	@RequestMapping(method=RequestMethod.GET, value="customers")
	public ResponseEntity<?> getCustomersList(){
		
		List<Customer> allCustomers=new ArrayList<Customer>();
		ResponseEntity<List<Customer>> responseEntity=null;
		
		try{
			service=(AdminService) ContextFactory.getContext().getBean(AdminServiceImpl.class);
			allCustomers=service.getCustomersList();
			if(!allCustomers.isEmpty()){
			responseEntity= new ResponseEntity<List<Customer>>(allCustomers,HttpStatus.OK);}
		}catch(Exception e){
			return null;
		}
		
		return responseEntity;
	}
	
	@RequestMapping(method=RequestMethod.GET,value="customers/{username}")
	public ResponseEntity<Customer> getCustomerByUserName(@PathVariable String username){
		
		Customer customer =new Customer();
		ResponseEntity<Customer> responseEntity;
		
		try{
			service=(AdminService) ContextFactory.getContext().getBean(AdminServiceImpl.class);
			customer=service.getCUstomerByUserName(username);
			responseEntity=new ResponseEntity<Customer>(customer,HttpStatus.OK);
		}
		catch(Exception e){
			return null;
		}
		return responseEntity;
	}
	
	@RequestMapping(method=RequestMethod.DELETE,value="deleteCustomer/{username}")
	public ResponseEntity<Customer> deleteCustomer(@PathVariable String username){
		System.out.println(username);
		Customer customer =new Customer();
		ResponseEntity<Customer> responseEntity;
		
		try{
			service=(AdminService) ContextFactory.getContext().getBean(AdminServiceImpl.class);
			customer=service.deleteCustomer(username);
			responseEntity=new ResponseEntity<Customer>(customer,HttpStatus.OK);
	}catch(Exception e){
		return null;
	}

		return responseEntity;
	
	}
	
	
	@RequestMapping(method=RequestMethod.PUT,value="updateCustomer")
	public ResponseEntity<Customer> updateCustomer(@RequestBody Customer customer){
		
		
		ResponseEntity<Customer> responseEntity;
		
		try{
			service=(AdminService) ContextFactory.getContext().getBean(AdminServiceImpl.class);
			customer=service.updateCustomer(customer);
			responseEntity=new ResponseEntity<Customer>(customer,HttpStatus.OK);
	}catch(Exception e){
		return null;
	}

		return responseEntity;
	}
	


	@RequestMapping(method=RequestMethod.GET,value="getSoldProductReport")
	public ResponseEntity<?> getSoldProductReport(){
		
		List<Product> soldProductList=new ArrayList<>();
		ResponseEntity<List<Product>> responseEntity = null;
		try{
			service=(AdminService) ContextFactory.getContext().getBean(AdminServiceImpl.class);
			soldProductList=service.getSoldProductList();
			responseEntity=new ResponseEntity<List<Product>>(soldProductList,HttpStatus.OK);
		}catch(Exception e){
			return null;
		}
		return responseEntity;
	}

		@RequestMapping(method=RequestMethod.GET,value="getAllBids")
	public ResponseEntity<?> getAllBids(){
		
		List<Product> getAllBids=new ArrayList<>();
		ResponseEntity<List<Product>> responseEntity = null;
		try{
			service=(AdminService) ContextFactory.getContext().getBean(AdminServiceImpl.class);
			getAllBids=service.getAllBids();
			responseEntity=new ResponseEntity<List<Product>>(getAllBids,HttpStatus.OK);
		}catch(Exception e){
			return null;
		}
		return responseEntity;
	}
		

		
		
		

		
		@RequestMapping(method=RequestMethod.GET,value="getProductsForReview")
		public ResponseEntity<?> getProductsForReview(){
			
			List<Product> reviewProductList=new ArrayList<>();
			ResponseEntity<List<Product>> responseEntity =null;
			try{
				service=(AdminService) ContextFactory.getContext().getBean(AdminServiceImpl.class);
				reviewProductList=service.getProductsForReview();
				System.out.println(reviewProductList);
				responseEntity=new ResponseEntity<List<Product>>(reviewProductList,HttpStatus.OK);
			}catch(Exception e){
				return null;
			}
			return responseEntity;
		}

		@RequestMapping(method=RequestMethod.PUT,value="updateProductStatus/{productId}")
		public ResponseEntity<String> updateProductStatus(@PathVariable Integer productId){

			
			
			ResponseEntity<String> responseEntity;
			
			try{
				service=(AdminService) ContextFactory.getContext().getBean(AdminServiceImpl.class);
				String status=service.updateProductStatus(productId);
				System.out.println("status is"+status);
				responseEntity=new ResponseEntity<String>(status,HttpStatus.OK);
		}catch(Exception e){
			System.out.println("caught exception");
			return null;
		}

			return responseEntity;
		}
		
		
		@RequestMapping(value="deleteProduct/{productId}", method = RequestMethod.DELETE)
		public ResponseEntity<String> deleteProduct(@PathVariable Integer productId) throws Exception{
			service = ContextFactory.getContext().getBean(AdminServiceImpl.class);
			System.out.println(productId);
			String sucessMessage =service.deleteProduct(productId);
			if(sucessMessage!=null){
				return new ResponseEntity<String>("Sucessfully Deleted",HttpStatus.OK);
			}
			else{
				return new ResponseEntity<String>("Failed to delete",HttpStatus.BAD_REQUEST);
			}
			
		}
		
        @RequestMapping(method=RequestMethod.GET,value="totalCustomers")
        public ResponseEntity<Integer> totalCustomers() throws Exception{
                        service = ContextFactory.getContext().getBean(AdminServiceImpl.class);
                        List customerList=new ArrayList();
                        customerList=service.getCustomersList();
                        Integer totalCustomers=customerList.size();
                        return new ResponseEntity<Integer>(totalCustomers,HttpStatus.OK);
        }
        
        @RequestMapping(method=RequestMethod.GET,value="totalSoldProducts")
        public ResponseEntity<Integer> totalSoldProducts() throws Exception{
                        service = ContextFactory.getContext().getBean(AdminServiceImpl.class);
                        List soldProducts=new ArrayList();
                        soldProducts=service.getSoldProductList();
                        Integer totalSoldProducts=soldProducts.size();
                        return new ResponseEntity<Integer>(totalSoldProducts,HttpStatus.OK);
        }
        
        @RequestMapping(method=RequestMethod.GET,value="totalProducts")
        public ResponseEntity<Integer> totalProducts() throws Exception{
                        
                        List allProducts=new ArrayList();
                        allProducts=service.getAllProductList();
                        Integer totalProducts=allProducts.size();
                        return new ResponseEntity<Integer>(totalProducts,HttpStatus.OK);
        }
        

}