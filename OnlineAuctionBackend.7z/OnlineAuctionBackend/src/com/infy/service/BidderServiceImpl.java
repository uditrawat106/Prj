package com.infy.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.infy.dao.BidderDAO;
import com.infy.model.Product;

@Service("bidderService")
@Transactional(readOnly = true)
public class BidderServiceImpl implements BidderService{

	@Autowired
	private BidderDAO dao;
	
	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public String bidOnProduct(String username, Integer productId, Double bid) throws Exception {
		
		String message = dao.bidOnProduct(username, productId, bid);
		if(message.equalsIgnoreCase("success"))
			return message;
		else
			throw new Exception("DAO.TECHNICAL_ERROR");
	}
	
	@Override
	@Transactional(readOnly = true, propagation = Propagation.REQUIRES_NEW)
	public List<Product> showMyBidProducts(String username) throws Exception {
		List<Product> myProducts = dao.showMyBidProducts(username);
		if(myProducts == null || myProducts.size()==0)
			throw new Exception("Bidder.No_Bid_Products");
		else
			return myProducts;
	}

	@Override
	public List<Product> showAboutToExpireProducts() throws Exception {
		
		List<Product> products = dao.showAboutToExpireProducts();
		if(products == null || products.size()==0)
			throw new Exception("Bidder.No_Products");
		else
			return products;
	}

	@Override
	public List<Product> showNewlyAddedProducts() throws Exception {
		
		List<Product> products = dao.showNewlyAddedProducts();
		if(products == null || products.size()==0)
			throw new Exception("Bidder.No_Products");
		else
			return products;
		
	}
	
	@Override
	public List<Product> showSoldProducts() throws Exception{
		
		List<Product> products = dao.showSoldProducts();
		if(products == null || products.size()==0)
			throw new Exception("Bidder.No_Products");
		else
			return products;
		
	}

	@Override
	public List<Product> showSearchedProducts(String search) throws Exception {
		
		List<Product> products = dao.showSearchedProducts(search);
		if(products == null || products.size()==0)
			throw new Exception("Bidder.No_Products");
		else
			return products;
		
	}

	@Override
	public List<Product> showProductAtLocattion(String location) throws Exception {
		
		List<Product> products = dao.showProductAtLocattion(location);
		if(products == null || products.size()==0)
			throw new Exception("Bidder.No_Products");
		else
			return products;
	}

	
	
}
