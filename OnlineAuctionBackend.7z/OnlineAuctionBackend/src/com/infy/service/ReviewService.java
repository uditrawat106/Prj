package com.infy.service;

import com.infy.model.ReviewsModel;

public interface ReviewService {
	
	public String addReview(String review);

}
