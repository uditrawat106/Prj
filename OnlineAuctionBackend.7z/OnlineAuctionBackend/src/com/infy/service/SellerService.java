package com.infy.service;

import java.util.List;

import com.infy.model.Product;

public interface SellerService {
	
	public List<Product> showMySoldProducts(String username) throws Exception;
	public Integer addProduct(Product product) throws Exception ;
	public List<Product> getMyProducts(String username) throws Exception;
	
	public String updateProductDetails(Product product) throws Exception;
	public String deleteProduct(Product product)throws Exception;
	public List<Product> searchByCategory(String category)  throws Exception;
	
	
}
