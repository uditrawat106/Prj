package com.infy.service;

import java.util.List;

import com.infy.model.AdminDetails;
import com.infy.model.Customer;
import com.infy.model.Product;

public interface AdminService {

	

	public List<Customer> getCustomersList() throws Exception;

	public Customer getCUstomerByUserName(String userName)throws Exception;

	public Customer deleteCustomer(String userName) throws Exception;

	public Customer updateCustomer(Customer customer) throws Exception;

	public List<Product> getSoldProductList() throws Exception;

	public String login(String userName) throws Exception;

	public AdminDetails getAdminDetails() throws Exception;

	public List<Product> getAllBids()  throws Exception;
	
	public List<Product> getProductsForReview() throws Exception;

	public String updateProductStatus(Integer productId) throws Exception;

	public String deleteProduct(Integer productId) throws Exception;
	
    public List getAllProductList();

	
}
