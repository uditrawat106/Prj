package com.infy.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.infy.dao.AdminDAO;
import com.infy.model.AdminDetails;
import com.infy.model.Customer;
import com.infy.model.Product;

@Service("adminService")
@Transactional(readOnly=true)
public class AdminServiceImpl implements AdminService {
	
	@Autowired
	private AdminDAO adminDAO;
	
	
	public List<Customer> getCustomersList() throws Exception{
		
		return adminDAO.getCustomerList();
	}
	
	public Customer getCUstomerByUserName(String userName) throws Exception{
		
		return adminDAO.getCustomerByUserName(userName);
	}
	
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public Customer deleteCustomer(String userName) throws Exception{
		System.out.println(userName);
		return adminDAO.deleteCustomer(userName);
	}
	
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public Customer updateCustomer(Customer customer) throws Exception{
		
		return adminDAO.updateCustomer(customer);
	}
	
	public List<Product> getSoldProductList() throws Exception{
		
		return adminDAO.getSoldProductList();
	}
	
	public String login(String userName) throws Exception{
		String password=adminDAO.getPassword(userName);
		return password; 
	}

	@Override
	public AdminDetails getAdminDetails() throws Exception {
		// TODO Auto-generated method stub
		
		return adminDAO.getAdminDetails();
	}

	@Override
	public List<Product> getAllBids() throws Exception {
		// TODO Auto-generated method stub
		return adminDAO.getAllBids();
	}
	
	@Override
	public List<Product> getProductsForReview() throws Exception {
		// TODO Auto-generated method stub
		System.out.println(adminDAO.getProductsForReview());
		return adminDAO.getProductsForReview();
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public String updateProductStatus(Integer productId) throws Exception {
		// TODO Auto-generated method stub
		return adminDAO.updateProductStatus(productId);
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public String deleteProduct(Integer productId) throws Exception {
		// TODO Auto-generated method stub
		System.out.println(productId);
		return adminDAO.deleteProduct(productId);
	}
   
	@Override
    public List getAllProductList() {
                    // TODO Auto-generated method stub
                    return adminDAO.getAllProductList();
    }


}
