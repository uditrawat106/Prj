package com.infy.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.infy.dao.AdminDAO;
import com.infy.dao.ReviewDAO;
import com.infy.model.ReviewsModel;


@Service("reviewService")
public class ReviewServiceImpl implements ReviewService{
	
	@Autowired
	private ReviewDAO reviewDAO;
	
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public String addReview(String review)
	{
		return reviewDAO.addReview(review);
	}
}
