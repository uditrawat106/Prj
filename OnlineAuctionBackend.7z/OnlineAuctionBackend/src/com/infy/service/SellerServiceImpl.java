package com.infy.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.infy.dao.SellerDAO;
import com.infy.model.Product;

@Service("sellerService")
@Transactional(readOnly = true)
public class SellerServiceImpl implements SellerService {
	
	@Autowired
	private SellerDAO dao;

	@Override
	@Transactional(readOnly = true, propagation = Propagation.REQUIRES_NEW)
	public List<Product> showMySoldProducts(String username) throws Exception {
		List<Product> myProducts = dao.showMySoldProducts(username);
		if(myProducts == null || myProducts.size()==0)
			return null;
		else
			return myProducts;
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public Integer addProduct(Product product) throws Exception {
		// TODO Auto-generated method stub
		Integer productId=dao.addProduct(product);
		return productId;
	}

	@Override
	public List<Product> getMyProducts(String username) throws Exception {
		// TODO Auto-generated method stub
		
		return dao.getMyProducts(username);
	}
	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public String updateProductDetails(Product product)
			throws Exception {
		// TODO Auto-generated method stub
		
		return dao.updateProductDetails(product);
	
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public String deleteProduct(Product product) throws Exception {
		// TODO Auto-generated method stub
		return dao.deleteProduct(product);
	}
	
	@Override
	public List<Product> searchByCategory(String category) throws Exception {
		// TODO Auto-generated method stub
		return dao.searchByCategory(category);
	}
}
