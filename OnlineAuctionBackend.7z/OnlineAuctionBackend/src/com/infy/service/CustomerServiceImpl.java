package com.infy.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.infy.dao.CustomerDAO;
import com.infy.dao.CustomerDAOImpl;
import com.infy.model.Customer;
import com.infy.model.Feedback;
import com.infy.model.Password;
import com.infy.utility.ContextFactory;

@Service("customerService")
@Transactional(readOnly = true)
public class CustomerServiceImpl implements CustomerService{

	private CustomerDAO dao;
	
	@Override
	public String loginCustomer(String email) throws Exception {
		
		dao = ContextFactory.getContext().getBean(CustomerDAOImpl.class);
		return dao.loginCustomer(email);
		
	}

	public List<String> getUsernames() throws Exception{
		
		dao = ContextFactory.getContext().getBean(CustomerDAOImpl.class);
		return dao.getUsernames();
		
	}
	
	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public Customer registerCustomer(Customer customer) throws Exception {
		
		dao = ContextFactory.getContext().getBean(CustomerDAOImpl.class);
		return dao.registerCustomer(customer);
		
	}
	
	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public String addProfilePicture(String username, String pic) throws Exception{
		
		dao = ContextFactory.getContext().getBean(CustomerDAOImpl.class);
		return dao.addProfilePicture(username, pic);
		
	}
	
	@Override
	public String getProfilePicture(String username) throws Exception{
		
		dao = ContextFactory.getContext().getBean(CustomerDAOImpl.class);
		return dao.getProfilePicture(username);
		
	}

	@Override
	public Customer showMyDetails(String email) throws Exception {

		dao = ContextFactory.getContext().getBean(CustomerDAOImpl.class);
		return dao.showMyDetails(email);
		
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public String updateProfile(Customer customer) throws Exception {

		dao = ContextFactory.getContext().getBean(CustomerDAOImpl.class);
		return dao.updateProfile(customer);
		
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public String changePassword(String username, Password password) throws Exception {
		
		dao = ContextFactory.getContext().getBean(CustomerDAOImpl.class);
		return dao.changePassword(username, password);
		
	}
	
	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public String submitFeedback(Feedback fb) throws Exception{
		
		dao = ContextFactory.getContext().getBean(CustomerDAOImpl.class);
		return dao.submitFeedback(fb);
		
	}
}
