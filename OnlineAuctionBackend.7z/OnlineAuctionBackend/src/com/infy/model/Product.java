package com.infy.model;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.infy.entity.BidsEntity;
import com.infy.entity.ProductEntity;

public class Product implements Comparable<Product>{
	
	private Integer productId;
	private String productName;
	private String category;
	private String description;
	private Integer basePrice;
	private LocalDate postedOn;
	private LocalDate removedOn;
	private String seller;
	private String address;
	private String bidder;
	private Double currentBid;
	private String image1, image2, image3, image4;
	private String reviewStatus;
	private List<Bids> bids;
	
	public Product(){
		
	}
	
	public Product(ProductEntity pe){
		this.setProductId(pe.getProductId());
		this.setProductName(pe.getProductName());
		this.setCategory(pe.getCategory());
		this.setDescription(pe.getDescription());
		this.setBasePrice(pe.getBasePrice());
		this.setPostedOn(pe.getPostedOn());
		this.setRemovedOn(pe.getRemovedOn());
		this.setSeller(pe.getSeller());
		if(pe.getAddress() != null)
			this.setAddress(pe.getAddress());
		if(pe.getBidder() != null)
			this.setBidder(pe.getBidder());
		if(pe.getCurrentBid() != null)
			this.setCurrentBid(pe.getCurrentBid());
		if(pe.getImage1() != null){
			this.setImage1(new String(pe.getImage1()));
		}
		if(pe.getImage2() != null){
			this.setImage2(new String(pe.getImage2()));
		}
		if(pe.getImage3() != null){
			this.setImage3(new String(pe.getImage3()));
		}
		if(pe.getImage4() != null){
			this.setImage4(new String(pe.getImage4()));
		}
		this.setReviewStatus(pe.getReviewStatus());
		if(pe.getBids() != null){
			this.bids = new ArrayList<Bids>();
			for(BidsEntity be : pe.getBids()){
				Bids b = new Bids(be);
				this.bids.add(b);
			}
		}
	}
	
	public Integer getProductId() {
		return productId;
	}
	public void setProductId(Integer productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Integer getBasePrice() {
		return basePrice;
	}
	public void setBasePrice(Integer basePrice) {
		this.basePrice = basePrice;
	}
	public String getSeller() {
		return seller;
	}
	public void setSeller(String seller) {
		this.seller = seller;
	}
	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}
	public String getBidder() {
		return bidder;
	}
	public void setBidder(String bidder) {
		this.bidder = bidder;
	}
	public Double getCurrentBid() {
		return currentBid;
	}
	public void setCurrentBid(Double currentBid) {
		this.currentBid = currentBid;
	}
	public LocalDate getPostedOn() {
		return postedOn;
	}
	public void setPostedOn(LocalDate postedOn) {
		this.postedOn = postedOn;
	}
	public LocalDate getRemovedOn() {
		return removedOn;
	}
	public void setRemovedOn(LocalDate removedOn) {
		this.removedOn = removedOn;
	}

	public String getImage1() {
		return image1;
	}

	public void setImage1(String image1) {
		this.image1 = image1;
	}

	public String getImage2() {
		return image2;
	}

	public void setImage2(String image2) {
		this.image2 = image2;
	}

	public String getImage3() {
		return image3;
	}

	public void setImage3(String image3) {
		this.image3 = image3;
	}

	public String getImage4() {
		return image4;
	}

	public void setImage4(String image4) {
		this.image4 = image4;
	}

	public String getReviewStatus() {
		return reviewStatus;
	}

	public void setReviewStatus(String reviewStatus) {
		this.reviewStatus = reviewStatus;
	}

	public List<Bids> getBids() {
		return bids;
	}

	public void setBids(List<Bids> bids) {
		this.bids = bids;
	}

	@Override
	public int compareTo(Product o) {
		return this.removedOn.compareTo(o.removedOn);
	}
}
