package com.infy.model;

public class ReviewsModel {
	
	Integer reviewId;
	String review;
	public Integer getReviewId() {
		return reviewId;
	}

	public void setReviewId(Integer reviewId) {
		this.reviewId = reviewId;
	}
	public String getReview() {
		return review;
	}

	public void setReview(String review) {
		this.review = review;
	}

}
