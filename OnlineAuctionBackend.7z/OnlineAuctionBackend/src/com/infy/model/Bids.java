package com.infy.model;

import com.infy.entity.BidsEntity;

public class Bids {

	private Integer bidId;
	private String bidder;
	private Double bid;
	
	public Bids(){
		
	}
	public Bids(BidsEntity be){
		this.setBidId(be.getBidId());
		this.setBid(be.getBid());
		this.setBidder(be.getBidder());
	}
	public Integer getBidId() {
		return bidId;
	}
	public void setBidId(Integer bidId) {
		this.bidId = bidId;
	}
	public String getBidder() {
		return bidder;
	}
	public void setBidder(String bidder) {
		this.bidder = bidder;
	}
	public Double getBid() {
		return bid;
	}
	public void setBid(Double bid) {
		this.bid = bid;
	}
	
}
