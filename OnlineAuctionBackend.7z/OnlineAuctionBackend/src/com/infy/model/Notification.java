package com.infy.model;

import java.time.LocalDate;

import com.infy.entity.NotificationEntity;

public class Notification implements Comparable<Notification>{
	
	private Integer notificationId;
	private String toUser;
	private String text;
	private LocalDate notificationTime;
	private String read;
	public Notification(){
		
	}
	public Notification(NotificationEntity ne){
		this.setToUser(ne.getToUser());
		this.setText(ne.getText());
		this.setNotificationTime(ne.getNotificationTime());
		this.setRead(ne.getRead());
	}
	public Integer getNotificationId() {
		return notificationId;
	}
	public void setNotificationId(Integer notificationId) {
		this.notificationId = notificationId;
	}
	public String getToUser() {
		return toUser;
	}
	public void setToUser(String toUser) {
		this.toUser = toUser;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	public LocalDate getNotificationTime() {
		return notificationTime;
	}
	public void setNotificationTime(LocalDate notificationTime) {
		this.notificationTime = notificationTime;
	}
	public String getRead() {
		return read;
	}
	public void setRead(String read) {
		this.read = read;
	}
	@Override
	public int compareTo(Notification o) {
		return this.getNotificationTime().compareTo(o.getNotificationTime());
	}
	
}
