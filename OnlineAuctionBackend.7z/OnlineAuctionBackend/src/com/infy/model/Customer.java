package com.infy.model;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.infy.entity.CustomerEntity;
import com.infy.entity.ProductEntity;

public class Customer {

	private String username;
	private String name;
	private String password;
	private String email;
	private String address;
	private LocalDate registeredOn;
	private Long phno;
	private String profilePic;
	private String message;
	private List<Product> sold;
	
	public Customer(){
		
	}
	public Customer(CustomerEntity ce){
		this.setUsername(ce.getUsername());
		this.setName(ce.getName());
		this.setPassword(ce.getPassword());
		this.setEmail(ce.getEmail());
		if(ce.getAddress() != null)
			this.setAddress(ce.getAddress());
		this.setRegisteredOn(ce.getRegisteredOn());
		if(ce.getPhno() != null)
			this.setPhno(ce.getPhno());
		if(ce.getProfilePic() != null){
			this.setProfilePic(new String(ce.getProfilePic()));
		}
		if(ce.getSold() != null){
			this.sold = new ArrayList<Product>();
			for(ProductEntity pe : ce.getSold()){
				Product p = new Product(pe);
				this.sold.add(p);			
			}
		}
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public LocalDate getRegisteredOn() {
		return registeredOn;
	}
	public void setRegisteredOn(LocalDate registeredOn) {
		this.registeredOn = registeredOn;
	}
	public Long getPhno() {
		return phno;
	}
	public void setPhno(Long phno) {
		this.phno = phno;
	}
	public String getProfilePic() {
		return profilePic;
	}
	public void setProfilePic(String profilePic) {
		this.profilePic = profilePic;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public List<Product> getSold() {
		return sold;
	}
	public void setSold(List<Product> sold) {
		this.sold = sold;
	}
}
