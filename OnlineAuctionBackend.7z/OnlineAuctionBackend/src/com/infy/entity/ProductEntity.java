package com.infy.entity;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import com.infy.model.Bids;
import com.infy.model.Product;

@Entity
@Table(name="Product")
@GenericGenerator(name="pkGen", strategy="increment")
public class ProductEntity {

	@Id
	@GeneratedValue(generator="pkGen")
	private Integer productId;
	private String productName;
	private String category;
	private String description;
	private Integer basePrice;
	private LocalDate postedOn;
	private LocalDate removedOn;
	private String seller;
	private String address;
	private String bidder;
	private Double currentBid;
	private byte[] image1, image2, image3, image4;
	private String reviewStatus;
	
	@OneToMany(cascade = CascadeType.ALL)
	@JoinTable(name="ProductBid",
	joinColumns = @JoinColumn(name="productId", referencedColumnName="productId"),
	inverseJoinColumns = @JoinColumn(name="bidId", referencedColumnName="bidId", unique=true))
	private List<BidsEntity> bids;
	
	public ProductEntity(){
		
	}
	public ProductEntity(Product p){
		this.setProductId(p.getProductId());
		this.setProductName(p.getProductName());
		this.setCategory(p.getCategory());
		this.setDescription(p.getDescription());
		this.setBasePrice(p.getBasePrice());
		this.setPostedOn(p.getPostedOn());
		this.setRemovedOn(p.getRemovedOn());
		this.setSeller(p.getSeller());
		if(p.getAddress() != null)
			this.setAddress(p.getAddress());
		if(p.getBidder() != null)
			this.setBidder(p.getBidder());
		if(p.getCurrentBid() != null)
			this.setCurrentBid(p.getCurrentBid());
		if(p.getImage1() != null){
			this.setImage1(p.getImage1().split(",")[1].getBytes());
		}
		if(p.getImage2() != null){
			this.setImage2(p.getImage2().split(",")[1].getBytes());
		}
		if(p.getImage3() != null){
			this.setImage3(p.getImage3().split(",")[1].getBytes());
		}
		if(p.getImage4() != null){
			this.setImage4(p.getImage4().split(",")[1].getBytes());
		}
		this.setReviewStatus(p.getReviewStatus());
		if(p.getBids() != null){
			this.bids = new ArrayList<BidsEntity>();
			for(Bids b : p.getBids()){
				BidsEntity be = new BidsEntity(b);
				this.bids.add(be);
			}
		}
	}
	public Integer getProductId() {
		return productId;
	}
	public void setProductId(Integer productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Integer getBasePrice() {
		return basePrice;
	}
	public void setBasePrice(Integer basePrice) {
		this.basePrice = basePrice;
	}
	public LocalDate getPostedOn() {
		return postedOn;
	}
	public void setPostedOn(LocalDate postedOn) {
		this.postedOn = postedOn;
	}
	public LocalDate getRemovedOn() {
		return removedOn;
	}
	public void setRemovedOn(LocalDate removedOn) {
		this.removedOn = removedOn;
	}
	public String getSeller() {
		return seller;
	}
	public void setSeller(String seller) {
		this.seller = seller;
	}
	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}
	public String getBidder() {
		return bidder;
	}
	public void setBidder(String bidder) {
		this.bidder = bidder;
	}
	public Double getCurrentBid() {
		return currentBid;
	}
	public void setCurrentBid(Double currentBid) {
		this.currentBid = currentBid;
	}
	public byte[] getImage1() {
		return image1;
	}
	public void setImage1(byte[] image1) {
		this.image1 = image1;
	}
	public byte[] getImage2() {
		return image2;
	}
	public void setImage2(byte[] image2) {
		this.image2 = image2;
	}
	public byte[] getImage3() {
		return image3;
	}
	public void setImage3(byte[] image3) {
		this.image3 = image3;
	}
	public byte[] getImage4() {
		return image4;
	}
	public void setImage4(byte[] image4) {
		this.image4 = image4;
	}
	public String getReviewStatus() {
		return reviewStatus;
	}
	public void setReviewStatus(String reviewStatus) {
		this.reviewStatus = reviewStatus;
	}
	public List<BidsEntity> getBids() {
		return bids;
	}
	public void setBids(List<BidsEntity> bids) {
		this.bids = bids;
	}
	
}
