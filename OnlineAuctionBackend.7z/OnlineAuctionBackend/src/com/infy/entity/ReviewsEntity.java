package com.infy.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="reviews")
public class ReviewsEntity {
	
 @Id
 @GeneratedValue(strategy=GenerationType.AUTO) 
 Integer reviewId;
 String review;
 
 
public Integer getReviewId() {
	return reviewId;
}
public void setReviewId(Integer reviewId) {
	this.reviewId = reviewId;
}
public String getReview() {
	return review;
}
public void setReview(String review) {
	this.review = review;
}

}
