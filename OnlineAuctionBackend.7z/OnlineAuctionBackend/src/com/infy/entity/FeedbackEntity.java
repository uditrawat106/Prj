package com.infy.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import com.infy.model.Feedback;

@Entity
@Table(name="Feedback")
@GenericGenerator(name="fIdGen", strategy="increment")
public class FeedbackEntity {

	@Id
	@GeneratedValue(generator="fIdGen")
	private Integer fId;
	private String byUser;
	private String reaction;
	private String satisfaction;
	private String recommend;
	private String feed;
	public FeedbackEntity(){
		
	}
	public FeedbackEntity(Feedback fb){
		this.setByUser(fb.getByUser());
		this.setReaction(fb.getReaction());
		this.setSatisfaction(fb.getSatisfaction());
		this.setRecommend(fb.getRecommend());
		this.setFeed(fb.getFeed());
	}
	public Integer getfId() {
		return fId;
	}
	public void setfId(Integer fId) {
		this.fId = fId;
	}
	public String getByUser() {
		return byUser;
	}
	public void setByUser(String byUser) {
		this.byUser = byUser;
	}
	public String getReaction() {
		return reaction;
	}
	public void setReaction(String reaction) {
		this.reaction = reaction;
	}
	public String getSatisfaction() {
		return satisfaction;
	}
	public void setSatisfaction(String satisfaction) {
		this.satisfaction = satisfaction;
	}
	public String getRecommend() {
		return recommend;
	}
	public void setRecommend(String recommend) {
		this.recommend = recommend;
	}
	public String getFeed() {
		return feed;
	}
	public void setFeed(String feed) {
		this.feed = feed;
	}
	
	
}
