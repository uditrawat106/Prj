package com.infy.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import com.infy.model.Bids;

@Entity
@Table(name="Bids")
@GenericGenerator(name="idGen", strategy="increment")
public class BidsEntity {

	@Id
	@GeneratedValue(generator="idGen")
	private Integer bidId;
	private String bidder;
	private Double bid;

	public BidsEntity() {
		
	}
	public BidsEntity(Bids  bids) {
		this.setBidId(bids.getBidId());
		this.setBid(bids.getBid());
		this.setBidder(bids.getBidder());
	}
	public Integer getBidId() {
		return bidId;
	}
	public void setBidId(Integer bidId) {
		this.bidId = bidId;
	}
	public String getBidder() {
		return bidder;
	}
	public void setBidder(String bidder) {
		this.bidder = bidder;
	}
	public Double getBid() {
		return bid;
	}
	public void setBid(Double bid) {
		this.bid = bid;
	}
	
}
