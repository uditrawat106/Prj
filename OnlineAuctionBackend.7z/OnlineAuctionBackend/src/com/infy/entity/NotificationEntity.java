package com.infy.entity;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import com.infy.model.Notification;

@Entity
@Table(name="Notification")
@GenericGenerator(name="nIdGen", strategy="increment")
public class NotificationEntity {

	@Id
	@GeneratedValue(generator="nIdGen")
	private Integer notificationId;
	private String toUser;
	private String text;
	private LocalDate notificationTime;
	private String read;
	public NotificationEntity(){
		
	}
	public NotificationEntity(Notification nt) {
		this.setToUser(nt.getToUser());
		this.setText(nt.getText());
		this.setNotificationTime(nt.getNotificationTime());
		this.setRead(nt.getRead());
	}
	public Integer getNotificationId() {
		return notificationId;
	}
	public void setNotificationId(Integer notificationId) {
		this.notificationId = notificationId;
	}
	public String getToUser() {
		return toUser;
	}
	public void setToUser(String toUser) {
		this.toUser = toUser;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	public LocalDate getNotificationTime() {
		return notificationTime;
	}
	public void setNotificationTime(LocalDate notificationTime) {
		this.notificationTime = notificationTime;
	}
	public String getRead() {
		return read;
	}
	public void setRead(String read) {
		this.read = read;
	}
	
}
