package com.infy.entity;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.infy.model.Customer;
import com.infy.model.Product;

@Entity
@Table(name="Customer")
public class CustomerEntity {
	
	@Id
	private String username;
	private String name;
	private String password;
	private String email;
	private String address;
	private LocalDate registeredOn;
	private Long phno;
	private byte[] profilePic;
	@OneToMany(cascade = CascadeType.ALL)
	@JoinTable(name="CustomerProduct",
	joinColumns = @JoinColumn(name="username", referencedColumnName="username"),
	inverseJoinColumns = @JoinColumn(name="productId", referencedColumnName="productId", unique=true))
	private List<ProductEntity> sold;
	
	public CustomerEntity(){
		
	}
	
	public CustomerEntity(Customer customer){
		this.setUsername(customer.getUsername());
		this.setName(customer.getName());
		this.setPassword(customer.getPassword());
		this.setEmail(customer.getEmail());
		if(customer.getAddress() != null)
			this.setAddress(customer.getAddress());
		this.setRegisteredOn(customer.getRegisteredOn());
		if(customer.getPhno() != null)
			this.setPhno(customer.getPhno());
		if(customer.getProfilePic() != null){
			String[] strings = customer.getProfilePic().split(",");
			byte[] pp = strings[1].getBytes();
			this.setProfilePic(pp);
		}
		if(customer.getSold() != null){
			this.sold = new ArrayList<ProductEntity>();
			for(Product p : customer.getSold()){
				ProductEntity pe = new ProductEntity(p);
				this.sold.add(pe);			}
		}
	}
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public LocalDate getRegisteredOn() {
		return registeredOn;
	}

	public void setRegisteredOn(LocalDate registeredOn) {
		this.registeredOn = registeredOn;
	}

	public Long getPhno() {
		return phno;
	}

	public void setPhno(Long phno) {
		this.phno = phno;
	}

	public byte[] getProfilePic() {
		return profilePic;
	}

	public void setProfilePic(byte[] profilePic) {
		this.profilePic = profilePic;
	}

	public List<ProductEntity> getSold() {
		return sold;
	}
	public void setSold(List<ProductEntity> sold) {
		this.sold = sold;
	}
}
