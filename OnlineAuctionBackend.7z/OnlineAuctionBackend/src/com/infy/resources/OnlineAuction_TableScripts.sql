
Drop table Customer cascade constraints;
Drop table Product cascade constraints;
Drop table Bids cascade constraints;
Drop table productbid cascade constraints;
Drop table CustomerProduct cascade constraints;
Drop table AdminDetails cascade constraints;
Drop table Feedback cascade constraints;
Drop table reviews;
Drop sequence review;
create sequence review start with 6660;

CREATE TABLE Customer(
    username VARCHAR2(30) NOT NULL,
    name VARCHAR2(20) NOT NULL,
    password VARCHAR2(20) NOT NULL,
    email VARCHAR2(30) NOT NULL UNIQUE,
    address VARCHAR2(100),
    registeredOn DATE NOT NULL,
    phno NUMBER(10) UNIQUE,
    profilePic BLOB,
    CONSTRAINT cust_uid_pk PRIMARY KEY(username)
);

INSERT INTO CUSTOMER VALUES('raghav10', 'Raghav', '@Raghav10', 'raghav10.trn', 'Mysore', SYSDATE-2, 8765453430, null);
INSERT INTO CUSTOMER VALUES('udit04', 'Udit', '@Udit040', 'udit04.trn', 'Mysore', SYSDATE-3, 8077281563, null);
INSERT INTO CUSTOMER VALUES('shashi01', 'Shashi', '@Shashi01', 'shashi01.trn', 'Mysore', SYSDATE-4, 7017968250, null);
INSERT INTO CUSTOMER VALUES('himanshu01', 'Himanshu', '@Himanshu01', 'himanshu01.trn', 'Pune', SYSDATE-2, 7055962369, null);
INSERT INTO CUSTOMER VALUES('tarun03', 'Tarun', '@Tarun03', 'tarun03.trn', 'Noida', SYSDATE-1, 9557946768, null);
INSERT INTO CUSTOMER VALUES('arpit01', 'Arpit', '@Arpit01', 'arpit01.trn', 'Chennai', SYSDATE-5, 9542512245, null);
INSERT INTO CUSTOMER VALUES('shreyas04', 'Shreyas', '@Shreyas04', 'shreyas04.trn', 'Mangalore', SYSDATE-3, 9760839395, null);
INSERT INTO CUSTOMER VALUES('adrika01', 'Adrika', '@Adrika01', 'adrika01.trn', 'Chennai', SYSDATE-2, 7055215486, null);
INSERT INTO CUSTOMER VALUES('swapnil07', 'Swapnil', '@Swapnil07', 'swapnil07.trn', 'Lucknow', SYSDATE, 6347254869, null);
INSERT INTO CUSTOMER VALUES('shivam36', 'Shivam', '@Shivam36', 'shivam36.trn', 'Dehradun', SYSDATE-6, 8065588156, null);

CREATE TABLE Product(
    productId number NOT NULL,
    productName VARCHAR2(50) NOT NULL,
    category VARCHAR2(20) NOT NULL,
    description VARCHAR2(200) NOT NULL,
    basePrice NUMBER NOT NULL,
    postedOn DATE NOT NULL,
    removedOn DATE NOT NULL,
    seller VARCHAR2(30) NOT NULL CONSTRAINT prod_seller_fk REFERENCES Customer(username),
    address VARCHAR2(100),
	bidder VARCHAR2(30) CONSTRAINT prod_bidder_fk REFERENCES Customer(username),
	currentBid NUMBER,
	image1 BLOB,
	image2 BLOB,
	image3 BLOB,
	image4 BLOB,
	reviewStatus VARCHAR2(1) NOT NULL,
    CONSTRAINT prod_pid_pk PRIMARY KEY(productId)
);

INSERT INTO PRODUCT VALUES(1000, 'McAfee total security Antivirus Kit', 'Electronics', 'A total security antivirus kit for your PC', 
	670, SYSDATE, SYSDATE+10, 'raghav10', 'Mysore', null, null, null, null, null, null, 'Y');
INSERT INTO PRODUCT VALUES(1001, 'Apple iPhone XS 256 GB', 'Electronics', 'Latest Apple iPhone XS(256 GB)', 
	114800, SYSDATE, SYSDATE+10, 'udit04', 'Mysore', null, null, null, null, null, null, 'Y');
INSERT INTO PRODUCT VALUES(1002, 'Samsung Level U Bluetooth Headset with Mic', 'Electronics', 'Premium bluetooth headset with mic.', 
	2500, SYSDATE, SYSDATE+10, 'udit04', 'Doon', null, null, null, null, null, null, 'Y');
	
INSERT INTO PRODUCT VALUES(1003, 'School Bag','Bags','More space and reliable',800,sysdate-11,sysdate-1,'raghav10','Lucknow','udit04', 1050, null, null, null, null, 'Y');
INSERT INTO PRODUCT VALUES(1004, 'Chair','Furniture','Comfortable',1200,sysdate-11,sysdate-1,'udit04','Jogiwala','raghav10', 1500, null, null, null, null, 'Y');
INSERT INTO PRODUCT VALUES(1005, 'Aviators','Apparel','Stylish',1000,sysdate-11,sysdate-1,'raghav10','Chennai','udit04', 1400, null, null, null, null, 'Y');
INSERT INTO PRODUCT VALUES(1006, 'Guitar','Music','Branded and in mint condition',1200,sysdate,sysdate+10,'shreyas04','Kolkata',null, null, null, null, null, null, 'N');
INSERT INTO PRODUCT VALUES(1007, 'Dining set','Home Decor','Beautiful engraving',900,sysdate,sysdate+10,'tarun03','Jharkhand',null, null, null, null, null, null, 'N');
INSERT INTO PRODUCT VALUES(1008, 'Let Us C','Books','Brand new condition without markings',1000,sysdate,sysdate+10,'swapnil07','Hyderabad',null, null, null, null, null, null, 'N');

CREATE TABLE CustomerProduct(
	username VARCHAR2(30) NOT NULL,
	productId number NOT NULL
);

INSERT INTO CustomerProduct VALUES('raghav10', 1000);
INSERT INTO CustomerProduct VALUES('udit04', 1001);
INSERT INTO CustomerProduct VALUES('udit04', 1002);
INSERT INTO CustomerProduct VALUES('raghav10', 1003);
INSERT INTO CustomerProduct VALUES('udit04', 1004);
INSERT INTO CustomerProduct VALUES('raghav10', 1005);
INSERT INTO CustomerProduct VALUES('shreyas04', 1006);
INSERT INTO CustomerProduct VALUES('tarun03', 1007);
INSERT INTO CustomerProduct VALUES('swapnil07', 1008);


CREATE TABLE Bids(
	bidId NUMBER PRIMARY KEY, 
	bidder VARCHAR2(30) CONSTRAINT bids_bidder_fk REFERENCES Customer(username),
	bid NUMBER NOT NULL
);

INSERT INTO BIDS VALUES(101, 'udit04', 1050);
INSERT INTO BIDS VALUES(102, 'raghav10', 1500);
INSERT INTO BIDS VALUES(103, 'udit04', 1400);

CREATE TABLE ProductBid(
	productId NUMBER NOT NULL,
	bidId NUMBER NOT NULL
);

INSERT INTO ProductBid VALUES(1003, 101);
INSERT INTO ProductBid VALUES(1004, 102);
INSERT INTO ProductBid VALUES(1005, 103);

CREATE TABLE ADMINDETAILS(
	username varchar2(30) primary key,
	password varchar(20) not null,
	name  varchar2(30),
	email  varchar2(30),
	address varchar2(30),
	phno NUMBER not null
);

INSERT INTO ADMINDETAILS VALUES('admin','password','Radhika K R','Radhika_Kr01@infosys.com','mysore',8765453430);

CREATE TABLE FEEDBACK(
	fId NUMBER PRIMARY KEY,
	byUser VARCHAR2(30) NOT NULL CONSTRAINT fbk_by_fk REFERENCES Customer(username),
	reaction VARCHAR2(1) CONSTRAINT fbk_rc_chk CHECK(reaction IN ('U', 'N', 'S')),
	satisfaction VARCHAR2(1) CONSTRAINT fbk_sf_chk CHECK(satisfaction IN ('U', 'N', 'S')),
	recommend VARCHAR2(1) CONSTRAINT fbk_rm_chk CHECK(recommend IN ('Y', 'M', 'N')),
	feed VARCHAR2(100)
);
create table reviews
 (
   reviewId number(20),
   review varchar2(100)
 )

SELECT productId,productName, reviewStatus FROM PRODUCT;
SELECT * FROM CUSTOMER;
SELECT * FROM BIDS;
SELECT * FROM PRODUCTBID;
SELECT * FROM FEEDBACk;
select * from  reviews;

UPDATE product set reviewStatus='Y';