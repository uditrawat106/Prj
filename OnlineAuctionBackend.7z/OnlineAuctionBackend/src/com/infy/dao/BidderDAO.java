package com.infy.dao;

import java.util.List;

import com.infy.model.Product;

public interface BidderDAO {

	public List<Product> showMyBidProducts(String username) throws Exception;
	
	public List<Product> showAboutToExpireProducts() throws Exception;
	public List<Product> showNewlyAddedProducts() throws Exception;
	public List<Product> showSoldProducts() throws Exception;
	public List<Product> showSearchedProducts(String search) throws Exception;
	public List<Product> showProductAtLocattion(String location) throws Exception;
	public String bidOnProduct(String username, Integer productId, Double bid) throws Exception;
}
