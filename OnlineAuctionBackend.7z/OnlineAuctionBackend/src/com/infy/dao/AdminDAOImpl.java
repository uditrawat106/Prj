package com.infy.dao;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.infy.entity.AdminDetailsEntity;
import com.infy.entity.BidsEntity;
import com.infy.entity.CustomerEntity;
import com.infy.model.AdminDetails;
import com.infy.model.Customer;
import com.infy.model.Product;
import com.infy.entity.ProductEntity;

@Repository("dao")
public class AdminDAOImpl implements AdminDAO {

	@Autowired
	SessionFactory sessionFactory;
	public String getPassword(String userName) throws Exception{
		
		
		Session session = sessionFactory.getCurrentSession();
		AdminDetailsEntity ad= session.get(AdminDetailsEntity.class,userName);
		System.out.println(ad.getPassword());
		if(ad!=null){
			return ad.getPassword();
		}
		return null;
	}
	@Override
	public List<Customer> getCustomerList() throws Exception{
		// TODO Auto-generated method stub
		
		Session session = sessionFactory.getCurrentSession();
		
		List<Customer> allCustomers =new ArrayList<>();
		
//		Query query=session.createQuery("select * from Customer");
		
		CriteriaBuilder criteriaBuilder = session.getCriteriaBuilder();
		CriteriaQuery<CustomerEntity> criteriaQuery = criteriaBuilder.createQuery(CustomerEntity.class);
		Root<CustomerEntity> root = criteriaQuery.from(CustomerEntity.class);
		criteriaQuery.select(root);
		Query<CustomerEntity> query = session.createQuery(criteriaQuery);
		List<CustomerEntity> allCustomersEntity = query.getResultList();
		
//		List<CustomerEntity> allCustomersEntity=query.list() ;
		
		System.out.println(allCustomersEntity);
		Customer customer = null;
		
		for(CustomerEntity ce: allCustomersEntity){
			
			customer =new  Customer(ce);
			allCustomers.add(customer);
			
		}
		
		
		return allCustomers;
	}
	
	@Override
	public Customer getCustomerByUserName(String userName) throws Exception {
		// TODO Auto-generated method stub
		
		Session session = sessionFactory.getCurrentSession();
		Customer customer=null;
		CustomerEntity customerEntity = session.get(CustomerEntity.class, userName);
		if(customerEntity!=null){
		customer=new Customer(customerEntity);}
		return customer;
	}
	@Override
	public Customer deleteCustomer(String username) throws Exception {
		// TODO Auto-generated method stub
		Session session = sessionFactory.getCurrentSession();
		System.out.println(username);
		Customer customer=null;
		CustomerEntity customerEntity = session.get(CustomerEntity.class,username);
		System.out.println(customerEntity.getName());
		if(customerEntity!=null){
			customer=new Customer(customerEntity);
			
		session.delete(customerEntity);
		}
		return customer;
	}
	@Override
	public Customer updateCustomer(Customer customer) throws Exception{
		// TODO Auto-generated method stub
		Session session = sessionFactory.getCurrentSession();
		CustomerEntity customerEntity=session.get(CustomerEntity.class,customer.getUsername());
		if(customerEntity!=null){
			customerEntity.setAddress(customer.getAddress());
			customerEntity.setName(customer.getName());
			customerEntity.setEmail(customer.getEmail());
			
		}
		return new Customer(customerEntity);
	}
	@Override
	public List<Product> getSoldProductList() throws Exception{
		// TODO Auto-generated method stub
		List<Product> allProducts=new ArrayList<>();
		Session session=sessionFactory.getCurrentSession();
//		Query query= session.createQuery("from Product");
		
		
		CriteriaBuilder criteriaBuilder = session.getCriteriaBuilder();
		CriteriaQuery<ProductEntity> criteriaQuery = criteriaBuilder.createQuery(ProductEntity.class);
		Root<ProductEntity> root = criteriaQuery.from(ProductEntity.class);
		criteriaQuery.select(root);
		Query<ProductEntity> query = session.createQuery(criteriaQuery);
		List<ProductEntity> allProductEntities = query.getResultList();
		
//		List<ProductEntity> allProductEntities=query.list();
		if(allProductEntities!=null){
			for(ProductEntity productEntity:allProductEntities){
				
					if((productEntity.getRemovedOn().isBefore(LocalDate.now()))){
						Product product=new Product(productEntity);
						allProducts.add(product);
					}
				}
			}
		return allProducts;
	}
	@Override
	public AdminDetails getAdminDetails() throws Exception {
		// TODO Auto-generated method stub
		
		Session session = sessionFactory.getCurrentSession();
		CriteriaBuilder criteriaBuilder = session.getCriteriaBuilder();
		CriteriaQuery<AdminDetailsEntity> criteriaQuery = criteriaBuilder.createQuery(AdminDetailsEntity.class);
		Root<AdminDetailsEntity> root = criteriaQuery.from(AdminDetailsEntity.class);
		criteriaQuery.select(root);
		Query<AdminDetailsEntity> query = session.createQuery(criteriaQuery);
		List<AdminDetailsEntity> allAdminEntities = query.getResultList();
		AdminDetails ad =new AdminDetails();
		for(AdminDetailsEntity adEntity:allAdminEntities){
			
			ad.setName(adEntity.getName());
			ad.setAddress(adEntity.getAddress());
			ad.setEmail(adEntity.getEmail());
			ad.setPhno(adEntity.getPhno());
			ad.setUsername(adEntity.getUsername());
		}
		return ad;
	}
	@Override
	public List<Product> getAllBids() throws Exception {
		// TODO Auto-generated method stub
		List<Product> allBidProducts = new ArrayList<>();
		Session session=sessionFactory.getCurrentSession();
//		Query query= session.createQuery("from Product");
		
		
		CriteriaBuilder criteriaBuilder = session.getCriteriaBuilder();
		CriteriaQuery<ProductEntity> criteriaQuery = criteriaBuilder.createQuery(ProductEntity.class);
		Root<ProductEntity> root = criteriaQuery.from(ProductEntity.class);
		criteriaQuery.select(root);
		Query<ProductEntity> query = session.createQuery(criteriaQuery);
		List<ProductEntity> allProductEntities = query.getResultList();
		
//		List<ProductEntity> allProductEntities=query.list();
		if(allProductEntities!=null){
			for(ProductEntity productEntity:allProductEntities){
					List<BidsEntity> bidlist = productEntity.getBids();
					if((bidlist.size()!=0) && (bidlist !=null)){
						Product product=new Product(productEntity);
						allBidProducts.add(product);
					}
				}
			}
		return allBidProducts;
	}
	
	@Override
	public List<Product> getProductsForReview() throws Exception {
		// TODO Auto-generated method stub
		Session session = sessionFactory.getCurrentSession();
		CriteriaBuilder builder = session.getCriteriaBuilder();
		CriteriaQuery<ProductEntity> criteriaQuery = builder.createQuery(ProductEntity.class);
		Root<ProductEntity> root = criteriaQuery.from(ProductEntity.class);
		criteriaQuery.select(root);
		criteriaQuery.where(builder.equal(root.get("reviewStatus"),"N"));
		List<ProductEntity> productEntities = session.createQuery(criteriaQuery).getResultList();
		System.out.println(productEntities);
		List<Product> products = new ArrayList<>();
		if(productEntities != null){
			for(ProductEntity pe : productEntities){
				Product p = new Product(pe);
				products.add(p);

			}
		}
		if(products.size()==0)
			return null;
		
		return products;
	}
	@Override
	public String updateProductStatus(Integer productId) throws Exception {
		// TODO Auto-generated method stub
		
		Session session = sessionFactory.getCurrentSession();
		ProductEntity productEntity=session.get(ProductEntity.class,productId);
		if(productEntity!=null){
		productEntity.setReviewStatus("Y");
		return "Status Updated Sucessfully";
		}
		else{
			return "Cannot Updated";
		}
	}
	@Override
	public String deleteProduct(Integer productId) throws Exception {
		// TODO Auto-generated method stub
		
		Session session = sessionFactory.getCurrentSession();
		ProductEntity pe= session.get(ProductEntity.class, productId);
		if(pe!=null){
		session.delete(pe);
		return "Deleted Sucessfully";
		}
		else{
			return "Not Deleted";
		}
		
	}
    @Override
    public List getAllProductList() {
                    Session session = sessionFactory.getCurrentSession();
                    CriteriaBuilder builder = session.getCriteriaBuilder();
                    CriteriaQuery<ProductEntity> criteriaQuery = builder.createQuery(ProductEntity.class);
                    Root<ProductEntity> root = criteriaQuery.from(ProductEntity.class);
                    criteriaQuery.select(root);
                    criteriaQuery.where(
                                                                                                                                    builder.equal(root.get("reviewStatus"), "Y")
                                                                                                    
                    );
                    List<ProductEntity> productEntities = session.createQuery(criteriaQuery).getResultList();
                    List<Product> products = new ArrayList<>();
                    for(ProductEntity pe : productEntities){
                                    products.add(new Product(pe));
                    }
                    
                    return products;
    }

	
	
	
}
	

