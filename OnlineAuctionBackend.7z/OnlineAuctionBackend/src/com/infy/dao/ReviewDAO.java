package com.infy.dao;

import com.infy.model.ReviewsModel;

public interface ReviewDAO {
	
	public String addReview(String review);

}
