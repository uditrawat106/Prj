package com.infy.dao;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.infy.entity.ProductEntity;
import com.infy.model.Product;


@Repository("sellerDao")
public class SellerDAOImpl implements SellerDAO {

	@Autowired
	SessionFactory sessionFactory;

	@Override
	public List<Product> showMySoldProducts(String username) throws Exception{
		
		Session session = sessionFactory.getCurrentSession();
		CriteriaBuilder builder = session.getCriteriaBuilder();
		CriteriaQuery<ProductEntity> criteriaQuery = builder.createQuery(ProductEntity.class);
		Root<ProductEntity> root = criteriaQuery.from(ProductEntity.class);
		criteriaQuery.select(root);
		criteriaQuery.where(builder.equal(root.get("seller"), username));
		List<ProductEntity> productEntities = session.createQuery(criteriaQuery).getResultList();
		List<Product> products = new ArrayList<>();
		if(productEntities != null){
			for(ProductEntity pe : productEntities){
				Product p = new Product(pe);
				products.add(p);
			}
		}
		if(products.size()==0)
			return null;
		return products;
	}
	

	@Override
	public Integer addProduct(Product product) throws Exception {
		// TODO Auto-generated method stub
		Session session = sessionFactory.getCurrentSession();
		ProductEntity productEntity;
		product.setPostedOn(LocalDate.now());
		product.setRemovedOn(LocalDate.now().plusDays(10));
		productEntity=new ProductEntity(product);
		
		return (Integer) session.save(productEntity);
	}


	@Override
	public List<Product> getMyProducts(String username) throws Exception {
		// TODO Auto-generated method stub
		
		Session session = sessionFactory.getCurrentSession();
		CriteriaBuilder builder = session.getCriteriaBuilder();
		CriteriaQuery<ProductEntity> criteriaQuery = builder.createQuery(ProductEntity.class);
		Root<ProductEntity> root = criteriaQuery.from(ProductEntity.class);
		criteriaQuery.select(root);
		criteriaQuery.where(builder.equal(root.get("seller"), username));
		List<ProductEntity> productEntities = session.createQuery(criteriaQuery).getResultList();
		List<Product> products = new ArrayList<>();
		if(productEntities != null){
			for(ProductEntity pe : productEntities){
				Product p = new Product(pe);
				products.add(p);
			}
		}
		if(products.size()==0)
			return null;
		return products;
		
	}
	
	@Override
	public String updateProductDetails(Product product)
			throws Exception {
		// TODO Auto-generated method stub
		Session session = sessionFactory.getCurrentSession();
		ProductEntity pe= session.get(ProductEntity.class, product.getProductId());
		pe.setProductName(product.getProductName());
		pe.setCategory(product.getCategory());
		pe.setDescription(product.getDescription());
		pe.setBasePrice(product.getBasePrice());
		
		return "Sucess";
		
	}


	@Override
	public String deleteProduct(Product product) throws Exception {
		// TODO Auto-generated method stub
		
		Session session = sessionFactory.getCurrentSession();
		ProductEntity pe= session.get(ProductEntity.class, product.getProductId());
		session.delete(pe);
		return "Deleted Sucessfully";
	}
	
	@Override
	public List<Product> searchByCategory(String category) throws Exception {
		// TODO Auto-generated method stub
		Session session = sessionFactory.getCurrentSession();
		CriteriaBuilder builder = session.getCriteriaBuilder();
		CriteriaQuery<ProductEntity> criteriaQuery = builder.createQuery(ProductEntity.class);
		Root<ProductEntity> root = criteriaQuery.from(ProductEntity.class);
		criteriaQuery.select(root);
		criteriaQuery.where(builder.equal(root.get("category"), category));
		List<ProductEntity> productEntities = session.createQuery(criteriaQuery).getResultList();
		List<Product> products = new ArrayList<>();
		if(productEntities != null){
			for(ProductEntity pe : productEntities){
				Product p = new Product(pe);
				products.add(p);
			}
		}
		if(products.size()==0)
			return null;
		return products;
		
	}
	
	
	
}
