package com.infy.dao;

import java.util.List;

import com.infy.model.Customer;
import com.infy.model.Feedback;
import com.infy.model.Password;

public interface CustomerDAO {

	public String loginCustomer(String email) throws Exception;
	public List<String> getUsernames() throws Exception;
	public Customer registerCustomer(Customer customer) throws Exception;
	public String addProfilePicture(String username, String pic) throws Exception;
	public String getProfilePicture(String username) throws Exception;
	
	public Customer showMyDetails(String email) throws Exception;
	public String updateProfile(Customer customer) throws Exception;
	public String changePassword(String username, Password password) throws Exception;
	
	public String submitFeedback(Feedback fb) throws Exception;
}
