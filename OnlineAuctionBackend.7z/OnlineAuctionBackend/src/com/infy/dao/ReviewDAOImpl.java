package com.infy.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.infy.entity.ReviewsEntity;
import com.infy.model.ReviewsModel;

@Repository("reviewdao")
public class ReviewDAOImpl implements ReviewDAO{
	
	@Autowired
	SessionFactory sessionFactory;
	
	
	@Override
	public String addReview(String review) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.getCurrentSession();
		ReviewsEntity entity=new ReviewsEntity();
		//entity.setReviewId(100);
		entity.setReview(review);
		session.persist(entity);
		return entity.getReview();
	}

}
