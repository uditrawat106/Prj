package com.infy.dao;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.infy.entity.BidsEntity;
import com.infy.entity.ProductEntity;
import com.infy.model.Product;


@Repository("bidderDao")
public class BidderDAOImpl implements BidderDAO {
	
	@Autowired
	SessionFactory sessionFactory;

	@Override
    public String bidOnProduct(String username, Integer productId, Double bid) throws Exception {
           
           Session session = sessionFactory.getCurrentSession();
           try{
                  ProductEntity pe = session.get(ProductEntity.class, productId);
                  BidsEntity be = null;
                  List<BidsEntity> bids = pe.getBids();
                  if(bids==null)
                        bids = new ArrayList<>();
                  else{
                	  for(BidsEntity bidsEntity : bids){
                		  if(bidsEntity.getBidder().equals(username)){
                			  be = bidsEntity;
                			  be.setBid(bid);
                		  }
                	  }
                  }
                  if(be == null){
                	  be = new BidsEntity();
                	  be.setBidder(username);
                	  be.setBid(bid);
                  }
                  bids.add(be);
                  pe.setBids(bids);
                  pe.setBidder(username);
                  pe.setCurrentBid(bid);
                  return "Success";
           } catch(Exception e){
                  return "Failure";
           }
    }

	@Override
	public List<Product> showMyBidProducts(String username) throws Exception {
		
		Session session = sessionFactory.getCurrentSession();
		CriteriaBuilder builder = session.getCriteriaBuilder();
		CriteriaQuery<ProductEntity> criteriaQuery = builder.createQuery(ProductEntity.class);
		Root<ProductEntity> root = criteriaQuery.from(ProductEntity.class);
		criteriaQuery.select(root);
		List<ProductEntity> productEntities = session.createQuery(criteriaQuery).getResultList();
		List<Product> products = new ArrayList<>();
		for(ProductEntity pe : productEntities){
			if(pe.getBids() != null){
				List<BidsEntity> bids = pe.getBids();
				for(BidsEntity be : bids){
					if(be.getBidder().equals(username)){
						Product p = new Product(pe);
						products.add(p);
					}
				}
			}
		}
		return products;
	}

	@Override
	public List<Product> showAboutToExpireProducts() throws Exception {
		
		Session session = sessionFactory.getCurrentSession();
		CriteriaBuilder builder = session.getCriteriaBuilder();
		CriteriaQuery<ProductEntity> criteriaQuery = builder.createQuery(ProductEntity.class);
		Root<ProductEntity> root = criteriaQuery.from(ProductEntity.class);
		criteriaQuery.select(root);
		List<ProductEntity> productEntities = session.createQuery(criteriaQuery).getResultList();
		List<Product> products = new ArrayList<>();
		LocalDate today = LocalDate.now();
		for(ProductEntity productEntity : productEntities){
			LocalDate removedOn = productEntity.getRemovedOn();
			if(removedOn.isBefore(today.plusDays(2)) && productEntity.getReviewStatus().equalsIgnoreCase("Y")){
				Product product = new Product(productEntity);
				products.add(product);
			}
		}
		
		return products;
	}

	@Override
	public List<Product> showNewlyAddedProducts() throws Exception {
		
		Session session = sessionFactory.getCurrentSession();
		CriteriaBuilder builder = session.getCriteriaBuilder();
		CriteriaQuery<ProductEntity> criteriaQuery = builder.createQuery(ProductEntity.class);
		Root<ProductEntity> root = criteriaQuery.from(ProductEntity.class);
		criteriaQuery.select(root);
		List<ProductEntity> productEntities = session.createQuery(criteriaQuery).getResultList();
		List<Product> products = new ArrayList<>();
		LocalDate today = LocalDate.now();
		for(ProductEntity productEntity : productEntities){
			LocalDate postedOn = productEntity.getPostedOn();
			if(postedOn.isAfter(today.minusDays(2)) && productEntity.getReviewStatus().equalsIgnoreCase("Y")){
				Product product = new Product(productEntity);
				products.add(product);
			}
		}
		Collections.sort(products, Collections.reverseOrder());
		return products;
	}
	
	@Override
	public List<Product> showSoldProducts() throws Exception{
		
		Session session = sessionFactory.getCurrentSession();
		CriteriaBuilder builder = session.getCriteriaBuilder();
		CriteriaQuery<ProductEntity> criteriaQuery = builder.createQuery(ProductEntity.class);
		Root<ProductEntity> root = criteriaQuery.from(ProductEntity.class);
		criteriaQuery.select(root);
		criteriaQuery.where(builder.and(
					builder.isNotNull(root.get("currentBid")),
					builder.lessThan(root.get("removedOn"), LocalDate.now())
				));
		List<ProductEntity> productEntities = session.createQuery(criteriaQuery).getResultList();
		List<Product> products = new ArrayList<>();
		for(ProductEntity pe : productEntities){
			products.add(new Product(pe));
		}
		
		return products;
		
	}

	@Override
	public List<Product> showSearchedProducts(String search) throws Exception {
		
		Session session = sessionFactory.getCurrentSession();
		CriteriaBuilder builder = session.getCriteriaBuilder();
		CriteriaQuery<ProductEntity> criteriaQuery = builder.createQuery(ProductEntity.class);
		Root<ProductEntity> root = criteriaQuery.from(ProductEntity.class);
		criteriaQuery.select(root);
		criteriaQuery.where(builder.and(
									builder.or(
											builder.like(builder.lower(root.get("productName")), "%"+search.toLowerCase()+"%"),
											builder.like(builder.lower(root.get("category")), "%"+search.toLowerCase()+"%"),
											builder.like(builder.lower(root.get("description")), "%"+search.toLowerCase()+"%")
									),
									builder.equal(root.get("reviewStatus"), "Y")
							)
		);
		List<ProductEntity> productEntities = session.createQuery(criteriaQuery).getResultList();
		List<Product> products = new ArrayList<>();
		for(ProductEntity pe : productEntities){
			if(pe.getRemovedOn().isAfter(LocalDate.now()))
					products.add(new Product(pe));
		}
		
		return products;
	}

	@Override
	public List<Product> showProductAtLocattion(String location) throws Exception {
		
		Session session = sessionFactory.getCurrentSession();
		CriteriaBuilder builder = session.getCriteriaBuilder();
		CriteriaQuery<ProductEntity> criteriaQuery = builder.createQuery(ProductEntity.class);
		Root<ProductEntity> root = criteriaQuery.from(ProductEntity.class);
		criteriaQuery.select(root);
		criteriaQuery.where(
					builder.like(builder.lower(root.get("address")), "%"+location.toLowerCase()+"%")
				);
		List<ProductEntity> productEntities = session.createQuery(criteriaQuery).getResultList();
		List<Product> products = new ArrayList<>();
		for(ProductEntity pe : productEntities){
			products.add(new Product(pe));
		}
		
		return products;
	}
}
