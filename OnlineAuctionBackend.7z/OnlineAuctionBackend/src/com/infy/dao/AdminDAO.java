package com.infy.dao;

import java.util.List;

import com.infy.model.AdminDetails;
import com.infy.model.Customer;
import com.infy.model.Product;

public interface AdminDAO {

	

	List<Customer> getCustomerList() throws Exception;

	Customer getCustomerByUserName(String userName) throws Exception;

	Customer deleteCustomer(String userName) throws Exception;

	Customer updateCustomer(Customer customer) throws Exception;

	List<Product> getSoldProductList() throws Exception;

	
	String getPassword(String userName) throws Exception;

	AdminDetails getAdminDetails() throws Exception;

	List<Product> getAllBids() throws Exception;
	
	List<Product> getProductsForReview() throws Exception;

	String updateProductStatus(Integer productId) throws Exception;

	String deleteProduct(Integer productId) throws Exception; 
   
    List getAllProductList(); 

}
