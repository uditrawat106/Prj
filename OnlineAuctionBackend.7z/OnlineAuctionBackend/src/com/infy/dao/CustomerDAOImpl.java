package com.infy.dao;

import java.time.LocalDate;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.infy.entity.CustomerEntity;
import com.infy.entity.FeedbackEntity;
import com.infy.model.Customer;
import com.infy.model.Feedback;
import com.infy.model.Password;

@Repository("customerDao")
public class CustomerDAOImpl implements CustomerDAO {
	
	@Autowired
	SessionFactory sessionFactory;
	
	@Override
	public String loginCustomer(String email) throws Exception {
		
		Session session = sessionFactory.getCurrentSession();
		CriteriaBuilder builder = session.getCriteriaBuilder();
		CriteriaQuery<String> query = builder.createQuery(String.class);
		Root<CustomerEntity> root = query.from(CustomerEntity.class);
		query.select(root.get("password"));
		query.where(builder.equal(root.get("email"), email));
		String pwd = session.createQuery(query).uniqueResult();
		if(pwd == null) throw new Exception("Customer.No_User_Found");
		return pwd;
		
	}

	@Override
	public List<String> getUsernames() throws Exception{
		
		Session session = sessionFactory.getCurrentSession();
		CriteriaBuilder builder = session.getCriteriaBuilder();
		CriteriaQuery<String> query = builder.createQuery(String.class);
		Root<CustomerEntity> root = query.from(CustomerEntity.class);
		query.select(root.get("username"));
		List<String> usernames = session.createQuery(query).getResultList();
		
		return usernames;
		
	}
	
	@Override
	public Customer registerCustomer(Customer customer) throws Exception {

		Session session = sessionFactory.getCurrentSession();
		
		Customer c = new Customer();
		CriteriaBuilder criteriaBuilder = session.getCriteriaBuilder();
		CriteriaQuery<CustomerEntity> criteriaQuery = criteriaBuilder.createQuery(CustomerEntity.class);
		Root<CustomerEntity> root = criteriaQuery.from(CustomerEntity.class);
		criteriaQuery.select(root);
		List<CustomerEntity> allCustomersEntity = session.createQuery(criteriaQuery).getResultList();
		
		for(CustomerEntity customerEntity : allCustomersEntity){
			if(customer.getPhno().equals(customerEntity.getPhno())){
				c.setMessage("Phone number already in use.");
				return c;
			}
			if(customer.getEmail().equalsIgnoreCase(customerEntity.getEmail())){
				c.setMessage("Email already in use.");
				return c;
			}
			if(customer.getUsername().equalsIgnoreCase(customerEntity.getUsername())){
				c.setMessage("Username already in use.");
				return c;
			}
			
		}
		CustomerEntity ce = new CustomerEntity(customer);
		ce.setRegisteredOn(LocalDate.now());
		session.persist(ce);
		c = new Customer(ce);
		c.setMessage("Success");
		return c;
	}

	@Override
	public String addProfilePicture(String username,  String pic) throws Exception {
		
		Session session= sessionFactory.getCurrentSession();
		CustomerEntity ce = session.get(CustomerEntity.class, username);
//		byte[] pp = Base64.decodeBase64(pic);
		String[] strings = pic.split(",");
		byte[] pp = strings[1].getBytes();
		ce.setProfilePic(pp);
		return "Success";
		
	}
	
	@Override
	public String getProfilePicture(String username) throws Exception{
		
		Session session = sessionFactory.getCurrentSession();
		CustomerEntity ce = session.get(CustomerEntity.class, username);
//		String pic = Base64.encodeBase64String(ce.getProfilePic());
		System.out.println(ce.getName());
		if(ce.getProfilePic() == null)
			return null;
		String pic = new String(ce.getProfilePic());
		return pic;
		
	}
	
	@Override
	public Customer showMyDetails(String email) throws Exception {

		Session session = sessionFactory.getCurrentSession();
		CriteriaBuilder builder = session.getCriteriaBuilder();
		CriteriaQuery<CustomerEntity> query = builder.createQuery(CustomerEntity.class);
		Root<CustomerEntity> root = query.from(CustomerEntity.class);
		query.select(root);
		query.where(builder.equal(root.get("email"), email));
		Customer customer = new Customer(session.createQuery(query).getSingleResult());
		
		return customer;
	}

	@Override
	public String updateProfile(Customer customer) throws Exception {

		Session session = sessionFactory.getCurrentSession();
		CustomerEntity ce = session.get(CustomerEntity.class, customer.getUsername());
		ce.setAddress(customer.getAddress());
		ce.setName(customer.getName());
			
		return ce.getUsername();
	}

	@Override
	public String changePassword(String username, Password password) throws Exception {
		
		Session session = sessionFactory.getCurrentSession();
		CustomerEntity ce = session.get(CustomerEntity.class, username);
		if(ce.getPassword().equals(password.getOldPassword())){
			if(password.getNewPassword().equals(password.getConfirmPassword())){
				ce.setPassword(password.getNewPassword());
			}
		}
		
		return "Success";
	}
	
	@Override
	public String submitFeedback(Feedback fb) throws Exception{
		
		Session session  = sessionFactory.getCurrentSession();
		FeedbackEntity fe = new FeedbackEntity(fb);
		session.persist(fe);
		return "Submitted Successfully";
		
	}
	
}